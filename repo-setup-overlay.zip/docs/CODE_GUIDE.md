# Code guide: how the Digital Equb backend works
Read this before you present. Every claim below points at a file you can open. If you cannot explain a part,
read the file and its test until you can; do not present code you cannot explain.

## 1. The idea in three sentences
An Equb is a group where N people each pay a fixed amount every cycle and one person takes the whole pot each cycle,
until everyone has had a turn. The risk is that someone stops paying, especially after receiving the pot.
This system records every payment and rule decision in a tamper-evident record, applies penalties fairly and
automatically, and gives early recipients less cash up front (holdback) to protect the people who are paid last.

## 2. Architecture
```
Browser (React)  ->  /api/v1/...  ->  Django REST views (thin)  ->  services/ (business rules)  ->  PostgreSQL
                                                         GitHub Actions cron (hourly) -> POST /api/v1/internal/run-deadlines/
```
**Why services/:** rules live in plain Python functions that do not depend on web requests, so they are easy to test
and cannot be bypassed by a different endpoint. Views only translate HTTP into service calls.

## 3. Folder map
| Path | What it is |
| --- | --- |
| `backend/config/` | Django settings (environment guards, security headers), URLs, test settings |
| `backend/apps/accounts/` | User model (phone login, role, standing), registration and login endpoints |
| `backend/apps/groups/` | Group, GroupTerms (versioned rules with a hash), Membership (slot, tier) |
| `backend/apps/cycles/` | Cycle (one round, with due date) and Obligation (one member's payment for a cycle) |
| `backend/apps/money/` | LedgerEntry (insert-only money record) and Payout |
| `backend/apps/audit/` | AuditEvent (hash-chained log) |
| `backend/apps/core/` | AppendOnlyModel base class, Clock (demo time travel), health and cron endpoints |
| `backend/services/` | tiers.py, payout.py, ladder.py, ledger.py, audit.py, deadlines.py, rules.py |
| `backend/tests/` | 21 tests that prove the rules (read these: they are the specification in code) |
| `docs/CHARTER.md` | The business rules in words |

## 4. Key ideas, where they live, and why
1. **Money is Decimal, never float** (`services/payout.py`, `LedgerEntry.amount`). Floats cannot represent 0.1 exactly; money errors are unacceptable.
2. **Append-only ledger** (`apps/core/models.py` AppendOnlyModel, `apps/money/models.py`). Rows can be added, never edited or deleted, so history cannot be rewritten. Balances are computed by summing rows (`services/ledger.py balance`), never stored. Limit: someone with raw database access could still change rows, which is why the audit chain and (planned) external anchoring exist.
3. **Idempotency** (`services/ledger.py record`). Each money write can carry a unique key; sending the same key again returns the original entry, so a double-click or retry cannot charge twice. Example: the fee uses key `fee:<obligation id>`.
4. **Hash-chained audit log** (`services/audit.py`). Each event stores the hash of the previous event; changing or deleting any row breaks every later hash. `verify_chain()` reports the first broken sequence number. Test: `tests/test_ledger_audit.py`.
5. **Payout tiers and holdback** (`services/tiers.py`, `services/payout.py`). Slots are split into early (first 30%), middle, late (last 30%). Holdback = rate x contribution x (N - slot) with rates 30% / 10% / 0%. Early recipients also pay a 2% premium that is meant to be shared among late-tier members. Why: this answers the instructors' "first, middle, last" risk feedback. Worked example (10 members, 1000 Br, slot 1): pot 10,000, premium 200, holdback 2,700, net 7,100.
6. **Penalty ladder** (`services/ladder.py`, pure function `evaluate`). Deadline is 23:59:59 Addis Ababa time on the due date. Then: grace (2 days, no fee), cure (3 days, one-time fee of 5%, capped at 10%, never compounded), then defaulted. An open dispute pauses the clock; an approved hardship extension moves the deadline. Why: fair notice before sanctions, like real contracts.
7. **Idempotent deadline job** (`services/deadlines.py`, called by `apps/core/views.py RunDeadlines`). Run hourly by GitHub Actions. Running it twice changes nothing the second time (tested). Why: free hosting sleeps, so we use an external timer instead of a background worker.
8. **Row locks and transactions** (`select_for_update`, `transaction.atomic` in services). Two simultaneous requests cannot both change the same row. Why: prevents double payment and double fees under concurrency.
9. **Auth** (`apps/accounts/`). Phone number is the login. Passwords hashed with bcrypt. JWT tokens (access 15 min). Registration ignores any `role` or `standing` the client sends (mass-assignment protection, tested). Login and register are rate limited.
10. **Environment guards** (`config/settings.py`). The app refuses to start in production with DEBUG or demo mode on, and requires a SECRET_KEY outside dev. Django's admin site is not installed. The 1 MB request limit and HTTPS settings turn on when DEBUG is off.
11. **Demo time travel** (`apps/core/clock.py`, `management/commands/simulate_time.py`). Only works when DEMO_MODE=1 (never production); lets you show a 10-day penalty sequence in a minute. It is a command-line tool, not a web endpoint.
12. **Cron endpoint security** (`apps/core/views.py`). POST only, secret token header, compared with `hmac.compare_digest` (constant-time, avoids timing leaks).

## 5. Honest status (say this if asked)
| Done and tested | Designed but NOT built yet |
| --- | --- |
| Tier and payout math, penalty ladder, ledger, audit chain, deadline job, register/login, cron endpoint, environment guards | Group, join, cycle and payment endpoints; payout execution with set-off; covering a shortfall; disputes and hardship; notices; password reset; refresh cookie; audit anchoring; the whole React frontend |

## 6. Likely questions, short answers
- **Why Django + PostgreSQL, not MongoDB?** A money ledger needs transactions and relations; Django gives auth and validation built in.
- **Why can't an admin edit a payment?** The ledger is insert-only; mistakes are fixed with a new reversing entry, which stays visible.
- **How do you stop double charging?** Idempotency keys plus database row locks.
- **What if the server sleeps and misses a deadline?** The hourly job catches up using the clock; it computes status from dates, not from "when it last ran".
- **Is any real money involved?** No. Payments are a sandbox simulation; real use needs legal review and payment licensing.
- **How do you protect early recipients not running away?** Holdback released with each later on-time payment, plus penalties and (planned) guarantor.
- **What stops someone changing history in the database?** Hash chain detects it; planned: publish the latest hash outside the database.
- **How do you know it works?** `./scripts/check.sh`: lint, 21 tests, security lint (bandit), dependency audit, secret scan.
- **Where is the weakest part?** Raw database access can bypass append-only guards; the auth refresh token is not yet in a cookie; the frontend and most endpoints do not exist yet.

## 7. Study exercises (do these once)
1. Run `python -m pytest -v` and read one test per file.
2. Change `fee_rate` to `0.07` in `services/rules.py` and see which test fails and why.
3. Open `ladder.py` and predict the status at 2026-11-13 09:00 for a 2026-11-10 due date; then check with `test_ladder.py`.
4. Edit an audit row in a test database and watch `verify_chain` catch it.

## 8. Honesty about tools
This project uses AI assistants to generate and review code. Follow your institution's rules for disclosing that,
and make sure you personally understand and can defend every file you submit.
