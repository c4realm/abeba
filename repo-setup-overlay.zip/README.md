# Digital Equb System
Mobile-first web app that digitizes the Ethiopian Equb (rotating savings group): groups, contributions,
fair late-payment steps, payout-risk tiers, and a tamper-evident audit log. Payments are a sandbox simulation only.

**Stack:** React + Vite + Tailwind (Vercel) | Django REST + PostgreSQL/Neon (Render) | GitHub Actions cron for deadlines.

## Where things are
- `backend/` Django API and business logic (`services/` holds the rules; start with `docs/CODE_GUIDE.md`)
- `frontend/` React app (design tokens exist; app scaffold is next)
- `docs/` CHARTER.md (rules), CODE_GUIDE.md (how the code works), DECISIONS.md, AGENT_LOG.md, prototypes/ (3D Ring and Pot)
- `scripts/` check.sh (all quality and security gates), setup_github.sh, tasks.json (plan), timeline builder
- `timeline.html` live project timeline (rebuild: `python3 scripts/build_timeline.py`)

## Run the checks (do this before every commit)
```
cd backend && python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt ruff bandit pip-audit && cd ..
./scripts/check.sh
```
Plan: 5 weeks, Nov 10 to Dec 14, 2026. Code freeze Dec 12. Workflow: see CONTRIBUTING.md and AGENTS.md.
