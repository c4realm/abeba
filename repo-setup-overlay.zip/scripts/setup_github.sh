#!/usr/bin/env bash
# Usage: ./scripts/setup_github.sh OWNER/digital-equb [public|private]
# Safe to re-run: it only creates what is missing. Set DRY_RUN=1 to preview without touching GitHub.
set -euo pipefail
cd "$(dirname "$0")/.."
REPO=${1:?usage: setup_github.sh OWNER/repo [public|private]}
VIS=${2:-public}                 # branch protection on free plans needs a public repo
REVIEWS=${REVIEWS:-1}            # approvals required to merge (use 0 if you work alone)
DRY=${DRY_RUN:-0}

if [ "$DRY" != "1" ]; then
  command -v gh >/dev/null || { echo "Install GitHub CLI first: sudo apt install gh"; exit 1; }
  gh auth status >/dev/null 2>&1 || { echo "Log in first: gh auth login"; exit 1; }
  git rev-parse HEAD >/dev/null 2>&1 || { echo "Make a first commit before running this script."; exit 1; }
  if ! gh repo view "$REPO" >/dev/null 2>&1; then
    gh repo create "$REPO" "--$VIS" --source=. --remote=origin --push
  else
    git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$REPO.git"
    git push -u origin main
  fi
fi

python3 - "$REPO" "$DRY" <<'PY'
import json, subprocess, sys

repo, dry = sys.argv[1], sys.argv[2] == "1"

def gh(*args, check=False):
    if dry:
        print("  [dry-run] gh", " ".join(args))
        return ""
    r = subprocess.run(["gh", *args], capture_output=True, text=True)
    if check and r.returncode:
        sys.exit(r.stderr)
    return r.stdout

LABELS = {"BE": "1d76db", "FE": "0e8a16", "UI": "e99695", "DOC": "fbca04", "ALL": "5319e7",
          "security": "b60205", "stretch": "cccccc"}
for name, color in LABELS.items():
    gh("label", "create", name, "-c", color, "-R", repo, "--force")

MILESTONES = {1: ("Week 1: Nov 10-16", "2026-11-16"), 2: ("Week 2: Nov 17-23", "2026-11-23"),
              3: ("Week 3: Nov 24-30", "2026-11-30"), 4: ("Week 4: Dec 1-7", "2026-12-07"),
              5: ("Week 5: Dec 8-14", "2026-12-14")}
have = {m["title"] for m in json.loads(gh("api", f"repos/{repo}/milestones?state=all&per_page=100") or "[]")}
for title, due in MILESTONES.values():
    if title not in have:
        gh("api", f"repos/{repo}/milestones", "-f", f"title={title}", "-f", f"due_on={due}T23:59:00Z")

existing = {i["title"] for i in json.loads(
    gh("issue", "list", "-R", repo, "--state", "all", "--limit", "500", "--json", "title") or "[]")}
made = 0
for week, stream, title, size in json.load(open("scripts/tasks.json")):
    if title in existing:
        continue
    labels = [stream] + (["stretch"] if title.startswith("STRETCH") else []) + (["security"] if "ecurity" in title else [])
    body = (f"**Size:** {size}  \n**Stream:** {stream}\n\n"
            "**Definition of done:** reviewed PR merged, `./scripts/check.sh` passes, tests added, "
            "working behaviour shown, `docs/AGENT_LOG.md` updated.")
    gh("issue", "create", "-R", repo, "-t", title, "-b", body, "-m", MILESTONES[week][0],
       *sum((["-l", l] for l in labels), []))
    made += 1
print(f"issues created: {made}, already existed: {len(existing)}")
PY

if [ "$DRY" != "1" ]; then
  # Branch protection: PR + approvals + passing CI before anything reaches main
  gh api -X PUT "repos/$REPO/branches/main/protection" --input - >/dev/null <<JSON || echo "WARNING: branch protection failed (needs a public repo or paid plan). Set it in Settings > Branches."
{"required_status_checks":{"strict":true,"contexts":["ci"]},"enforce_admins":false,
 "required_pull_request_reviews":{"required_approving_review_count":$REVIEWS},
 "restrictions":null,"allow_force_pushes":false,"allow_deletions":false}
JSON
  gh api -X PUT "repos/$REPO/vulnerability-alerts" >/dev/null 2>&1 || echo "note: could not enable Dependabot alerts"
  gh api -X PATCH "repos/$REPO" \
    -f 'security_and_analysis[secret_scanning][status]=enabled' \
    -f 'security_and_analysis[secret_scanning_push_protection][status]=enabled' >/dev/null 2>&1 \
    || echo "note: could not enable secret scanning (needs public repo or GitHub Advanced Security)"
fi
echo "Done. Next: create the Project board in the GitHub web UI (Projects > New project > Board > Add item > from repository)."
echo "Secrets are NOT set here. At deploy time add API_URL and CRON_TOKEN in Settings > Secrets > Actions."
